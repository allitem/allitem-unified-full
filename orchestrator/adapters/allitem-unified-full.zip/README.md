# allitem-unified (Full Upgrade)

Unified Orchestrator + QVNT Agent 6.5 (Quantum-Core Edition)
Production / Enterprise Ready
Supports future expansion with new repos and AI agents.

## Run
pip install -r requirements.txt
python api/server.py

## Docker
docker-compose up -d
