import sys, json
print(json.dumps({"repo":"social","input":sys.argv[1]}))
